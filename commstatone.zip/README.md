# commstatone
 # CommStatOne Ver 1.0.1 Released 03/12/23
<h3 style="color: #4485b8;">CommStat One Ver 1.0.1 add on software for JS8Call groups&nbsp;&nbsp;<img src="https://github.com/W5DMH/CommStatX/blob/main/CommStatXBeta.png?raw=true" alt="CommStat One Ver 1.0.1" width="300" height="170" /></h3>

CommstatX is a Python version of the CommStat software <b>designed to run on on Win10 AND Linux</b><br>
<br><br>
<b>NOTE : ALL USERS MUST RUN INSTALL ON THIS VERSION!<br></b>
<br>

<b>Commstatx WINDOWS INSTALL PROCEDURE</B>
<br>
NOTE : Saavy users can "git clone https://github.com/W5DMH/commstatone.git"
<br>
 To install, simply unzip the zipped folder below then: <br>
 <b>Type : cd commstatone <br>
  Type : python install.py </b> (or use : python3 install.py  if necessary) <br>
 You should get your settings popup, complete the settings then :<br>
 <b>Type : python commstat.py    or    python3 commstat.py (if your system requires python3) <b> NOT commstatx.py this has changed to commstat.py</b> 

<br>
 <br>
 
<b>Commstatx LINUX INSTALL PROCEDURE (Mint 20.03 & 21.1 Supported, Pi4 64bit may work)</B><br>
NOTE : Saavy users can "git clone https://github.com/W5DMH/commstatone.git"<br>
 <b>Type : cd commstatone <br>
 type : chmod +x linuxinstall.sh <br>
 type : ./linuxinstall.sh <br>
 enter your sudo password <br>
 After some installation you should get your settings popup, complete the settings then :<br>
 <b>Type : python commstat.py    or    python3 commstat.py (if your system requires python3) <b> NOT commstatx.py this has changed to commstat.py</b> 

<br><br><br>
=======
 
<h3>Here is a link to the archive file:&nbsp;<a href="https://github.com/W5DMH/commstatone/raw/main/commstatone.zip" target="_blank" rel="noopener">CommStat One 1.0.1 for Win10 & Win11 & Linux </a></h3>





Get CommStat Support at: <br>
https://groups.io/g/CommStat

I must give credit to m0iax for his JS8CallAPISupport Script as that is what makes the transmitting possible.See the rest of his JS8Call Tools here : https://github.com/m0iax
<br>
