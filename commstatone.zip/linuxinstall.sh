#!/bin/bash

sudo apt install python3-pyqt5.qtwebengine
python3 install.py

